// components/SitePreview.tsx
export default function SitePreview() {
    return (
      <div className="border rounded p-4 text-center text-muted-foreground">
        Site preview placeholder.
      </div>
    );
  }
  