'use client';
import { useRouter } from 'next/router';

export function DateFilterToolbar({
  basePath = '/admin/logs/feedback',
  label = 'Filter by Date'
}: {
  basePath?: string;
  label?: string;
}) {
  const router = useRouter();
  const { date } = router.query;

  return (
    <div className="mb-4 flex gap-2 items-center text-sm">
      <label>
        {label}:{' '}
        <input
          type="date"
          value={date ?? ''}
          onChange={(e) => {
            const newDate = e.target.value;
            router.push(\`\${basePath}?date=\${newDate}\`);
          }}
          className="bg-zinc-900 text-white border border-zinc-700 px-2 py-1 rounded"
        />
      </label>
      {date && (
        <button
          onClick={() => router.push(basePath)}
          className="text-xs text-blue-400 hover:underline"
        >
          Clear Filter
        </button>
      )}
    </div>
  );
}
