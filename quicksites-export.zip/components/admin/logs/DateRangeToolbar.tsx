'use client';
import { useRouter } from 'next/router';

export function DateRangeToolbar({
  label = 'Date Range',
  basePath = ''
}: {
  label?: string;
  basePath?: string;
}) {
  const router = useRouter();
  const { query } = router;
  const start = typeof query.start === 'string' ? query.start : '';
  const end = typeof query.end === 'string' ? query.end : '';

  return (
    <div className="mb-4 flex flex-wrap items-center gap-3 text-sm">
      <label>
        {label}:{' '}
        <input
          type="date"
          value={start}
          onChange={(e) => {
            const newStart = e.target.value;
            const url = new URLSearchParams(query as any);
            url.set('start', newStart);
            router.push(\`\${basePath}?$\{url.toString()}\`);
          }}
          className="bg-zinc-900 text-white border border-zinc-700 px-2 py-1 rounded"
        />
      </label>
      <label>
        to{' '}
        <input
          type="date"
          value={end}
          onChange={(e) => {
            const newEnd = e.target.value;
            const url = new URLSearchParams(query as any);
            url.set('end', newEnd);
            router.push(\`\${basePath}?$\{url.toString()}\`);
          }}
          className="bg-zinc-900 text-white border border-zinc-700 px-2 py-1 rounded"
        />
      </label>
      {(start || end) && (
        <button
          onClick={() => router.push(basePath || window.location.pathname)}
          className="text-xs text-blue-400 hover:underline"
        >
          Clear
        </button>
      )}
    </div>
  );
}
