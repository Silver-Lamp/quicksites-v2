# AdminLogToolbar Usage

This shared component provides a standardized toolbar for admin log views, including:

- 📅 CSV Date Range Export
- 🔍 Search Input
- 🔁 Pagination
- 🧩 Custom child controls

---

## Example

```tsx
import { AdminLogToolbar } from '@/components/admin/logs/AdminLogToolbar';

export default function FeedbackLogPage() {
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState('');

  return (
    <>
      <AdminLogToolbar
        type="feedback"
        page={page}
        onSearch={(term) => setQuery(term)}
        onPage={(newPage) => setPage(newPage)}
      >
        <button className="bg-zinc-700 px-3 py-1 rounded text-white">Extra</button>
      </AdminLogToolbar>
      {/* render filtered + paginated logs */}
    </>
  );
}
```

## Props

| Prop       | Type                       | Description                                |
|------------|----------------------------|--------------------------------------------|
| `type`     | `"feedback"` \| `"checkins"` | Determines export endpoint base path       |
| `page`     | `number`                   | Current page number                        |
| `onPage`   | `(n: number) => void`      | Triggered on next/prev click               |
| `onSearch` | `(term: string) => void`   | Triggered on input change                  |
| `children` | `React.ReactNode`          | Optional additional buttons or filters     |

---

## Dependencies

- [CSVDateRangeExport](./CSVDateRangeExport.tsx)
