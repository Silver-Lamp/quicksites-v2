# 👀 Viewer Guide

Welcome! This guide helps users who are previewing or using QuickSites-provided websites.

## 🔑 Access

Your assigned sites are listed under your dashboard:
```
https://quicksites.ai/viewer
```

## 📦 What You Can Do

- View demo sites assigned to you
- Share preview links with others
- Request claim or upgrade

## 🧼 Privacy

All activity is logged anonymously unless you sign in explicitly.
