alter table leads add column if not exists address_city text;
alter table leads add column if not exists address_state text;
