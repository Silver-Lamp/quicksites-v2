declare module '@/next-seo.config' {
    import { DefaultSeoProps } from 'next-seo';
    const config: DefaultSeoProps;
    export default config;
  }
  